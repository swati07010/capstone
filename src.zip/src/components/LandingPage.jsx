import React from 'react';
import { Link } from 'react-router-dom';
import JobDetails from './JobDetails';
import JobSearch from './JobSearch';
import JobList from './JobList';

function LandingPage() {
  return (

    <div className="container-fuild text-center mt-3">
      <h1 className="text-primary text-center my-4 pb-3 fw-bold shadow-sm text-uppercase">
        Welcome to Job Board Lite
      </h1>
      <JobList />
    </div>
  );
}

export default LandingPage;
