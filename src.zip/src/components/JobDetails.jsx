
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { fetchJobById } from '../api/Api'; 

function JobDetails() {
  const { id } = useParams();
  const [job, setJob] = useState(null);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchJobDetails = async () => {
      try {
        const response = await fetchJobById(id); 
        setJob(response.data);
      } catch (error) {
        console.error('Error fetching job details:', error);
        setError('Failed to load job details.');
      }
    };

    fetchJobDetails();
  }, [id]);

  const handleApplyClick = () => {
    navigate(`/applications/${id}`);
  };

  if (error) {
    return <div>{error}</div>;
  }

  if (!job) {
    return <div>Loading job details...</div>;
  }

  return (
    <div className="container mt-5 card p-5 bold shadow-lg">
      <h2 className="d-flex justify-content-center">{job.title}</h2>
      <p><strong>Company:</strong> {job.company}</p>
      <p><strong>Location:</strong> {job.location}</p>
      <p><strong>Salary Range:</strong> {job.salaryRange}</p>
      <p><strong>Description:</strong> {job.description}</p>
      <p><strong>Required Skills:</strong> {job.requiredSkills.join(', ')}</p>

      <div className="d-flex justify-content-center mt-4">
        <button className="btn btn-success" onClick={handleApplyClick}>
          Apply Now
        </button>
      </div>
    </div>
  );
}

export default JobDetails;
