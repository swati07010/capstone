import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { fetchJobs } from '../api/Api';
import JobSearch from './JobSearch'; // import your JobSearch component

function JobList() {
  const [jobs, setJobs] = useState([]);
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch jobs on mount
  useEffect(() => {
    fetchJobs()
      .then(response => {
        setJobs(response.data);
        setFilteredJobs(response.data); // initial state for filteredJobs
        setLoading(false);
      })
      .catch(error => {
        setError('Failed to load jobs');
        setLoading(false);
      });
  }, []);

  // Search handler — filters by job title
  const handleSearch = (searchValue) => {
    if (searchValue.trim() === '') {
      setFilteredJobs(jobs); 
      return;
    }

    const result = jobs.filter((job) =>
      job.title.toLowerCase().includes(searchValue.toLowerCase())
    );

    setFilteredJobs(result);
  };

  if (loading) return <div>Loading jobs...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div className="container mt-3 p-4">

      <JobSearch className="bold" onSearch={handleSearch} /> 

      <div className="row d-flex flex-wrap mt-5">
        {filteredJobs.length > 0 ? (
          filteredJobs.map((job) => (
            <div key={job.jobid} className="col-md-4 mb-4 d-flex ">
              <div className="card  w-100 h-100 p-4 border border-2 border border-primary p-3 rounded ">
                <div className="card-body d-flex flex-column">
                  <h5 className="card-title">{job.title}</h5>
                  <p className="card-text"><strong>Company:</strong> {job.company}</p>
                  <p className="card-text"><strong>Location:</strong> {job.location}</p>
                  <Link to={`/jobs/${job.jobid}`} className="btn btn-primary mt-auto">
                    View Details
                  </Link>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center mt-5">
            <h4>No results found.</h4>
          </div>
        )}
      </div>
    </div>
  );
}

export default JobList;
