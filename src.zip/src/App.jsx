import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LandingPage from './components/LandingPage';
import JobSearch from './components/JobSearch';
import JobDetails from './components/JobDetails';
import JobApplicationForm from './components/JobApplicationForm';
import ConfirmationMessage from './components/ConfirmationMessage';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<LandingPage />} />
          {/* <Route path="/search" element={<JobSearch />} /> */}
          <Route path="/jobs/:id" element={<JobDetails />} />
          <Route path="/applications/:id" element={<JobApplicationForm />} />
          <Route path="/confirmation" element={<ConfirmationMessage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
