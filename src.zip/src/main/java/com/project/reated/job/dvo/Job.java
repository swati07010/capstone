package com.project.reated.job.dvo;

import java.util.List;
import java.util.Objects;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;

@Entity
@Table(name = "jobs")

public class Job {

	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int jobid;

	    private String title;

	    private String company;

	    private String location;
	    
	    @Column(length = 2000)
	    private String description;

	    private String salaryRange;
	    
	    @ElementCollection
	    @CollectionTable(name = "job_skills", joinColumns = @JoinColumn(name = "job_id"))
	    @Column(name = "skill")
	    private List<String> requiredSkills;

		public Job() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Job(int jobid, String title, String company, String location, String description, String salaryRange,
				List<String> requiredSkills) {
			super();
			this.jobid = jobid;
			this.title = title;
			this.company = company;
			this.location = location;
			this.description = description;
			this.salaryRange = salaryRange;
			this.requiredSkills = requiredSkills;
		}

		public int getJobid() {
			return jobid;
		}

		public void setJobid(int jobid) {
			this.jobid = jobid;
		}

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		public String getCompany() {
			return company;
		}

		public void setCompany(String company) {
			this.company = company;
		}

		public String getLocation() {
			return location;
		}

		public void setLocation(String location) {
			this.location = location;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public String getSalaryRange() {
			return salaryRange;
		}

		public void setSalaryRange(String salaryRange) {
			this.salaryRange = salaryRange;
		}

		public List<String> getRequiredSkills() {
			return requiredSkills;
		}

		public void setRequiredSkills(List<String> requiredSkills) {
			this.requiredSkills = requiredSkills;
		}

		@Override
		public int hashCode() {
			return Objects.hash(company, description, jobid, location, requiredSkills, salaryRange, title);
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Job other = (Job) obj;
			return Objects.equals(company, other.company) && Objects.equals(description, other.description)
					&& jobid == other.jobid && Objects.equals(location, other.location)
					&& Objects.equals(requiredSkills, other.requiredSkills)
					&& Objects.equals(salaryRange, other.salaryRange) && Objects.equals(title, other.title);
		}
	    
	    
}
