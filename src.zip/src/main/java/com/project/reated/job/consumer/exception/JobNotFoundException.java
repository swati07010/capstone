package com.project.reated.job.consumer.exception;


public class JobNotFoundException extends RuntimeException {

    // Default constructor
    public JobNotFoundException() {
        super();
    }

    // Constructor with custom message
    public JobNotFoundException(String message) {
        super(message);
    }

    // Constructor with message and cause
    public JobNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    // Constructor with cause
    public JobNotFoundException(Throwable cause) {
        super(cause);
    }
}
