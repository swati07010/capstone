package com.project.reated.job.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.reated.job.consumer.exception.JobNotFoundException;
import com.project.reated.job.dvo.Job;
import com.project.reated.job.repository.JobRepository;

@Service
public class JobService {

    @Autowired
    private JobRepository jobRepository;

    // Fetch all jobs
    public List<Job> getAllJobs() {
        return jobRepository.findAll();
    }

    // Fetch job by ID, throw JobNotFoundException if not found
    public Job getJobById(int jobId) {
        return jobRepository.findById(jobId)
                .orElseThrow(() -> new JobNotFoundException("Job with ID " + jobId + " not found."));
    }
    
    

    // Save a new job
    public Job saveJob(Job job) {
        return jobRepository.save(job);
    }

    // Search jobs based on multiple criteria
    public List<Job> searchJobs(Integer jobid, String title, String company, String location) {
        return jobRepository.searchJobsByMultipleCriteria(jobid, title, company, location);
    }

    // Update job details
    public Job updateJob(int jobId, Job updatedJob) {
        Optional<Job> existingJobOptional = jobRepository.findById(jobId);

        if (existingJobOptional.isPresent()) {
            Job existingJob = existingJobOptional.get();
            existingJob.setTitle(updatedJob.getTitle());
            existingJob.setCompany(updatedJob.getCompany());
            existingJob.setLocation(updatedJob.getLocation());
            existingJob.setDescription(updatedJob.getDescription());
            existingJob.setSalaryRange(updatedJob.getSalaryRange());
            existingJob.setRequiredSkills(updatedJob.getRequiredSkills());

            return jobRepository.save(existingJob);
        } else {
            throw new JobNotFoundException("Job with ID " + jobId + " not found.");
        }
    }
}
