package com.project.reated.job.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.reated.job.dvo.Application;
import com.project.reated.job.dvo.Job;
import com.project.reated.job.service.ApplicationService;
import com.project.reated.job.service.JobService;

@RestController
@RequestMapping("/api/applications")
//@CrossOrigin(origins = "http://localhost:3000")
@CrossOrigin(origins = "*")

public class ApplicationController {

	@Autowired
    private ApplicationService applicationService;
	  
//	@PostMapping
//    public ResponseEntity<String> applyForJob(@RequestBody Application application) {
//        applicationService.applyForJob(application);
//        return ResponseEntity.ok("Application submitted successfully.");
//    }
	

	    @Autowired
	    private JobService jobService;  // Add JobService to get the Job object by ID

	    @PostMapping
	    public ResponseEntity<String> applyForJob(@RequestBody Application application) {
	        // Fetch the job by ID and set it in the application
	        Job job = jobService.getJobById(application.getJob().getJobid());  // Assuming the Application contains Job object with jobid
	        if (job != null) {
	            application.setJob(job);  // Set the job in the application
	            applicationService.applyForJob(application);
	            return ResponseEntity.ok("Application submitted successfully.");
	        } else {
	            return ResponseEntity.status(404).body("Job not found.");
	        }
	    }
}
