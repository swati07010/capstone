package com.project.reated.job.consumer.exception;


public class ApplicationNotFoundException extends RuntimeException {

    // Default constructor
    public ApplicationNotFoundException() {
        super();
    }

    // Constructor with custom message
    public ApplicationNotFoundException(String message) {
        super(message);
    }

    // Constructor with message and cause
    public ApplicationNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    // Constructor with cause
    public ApplicationNotFoundException(Throwable cause) {
        super(cause);
    }
}
