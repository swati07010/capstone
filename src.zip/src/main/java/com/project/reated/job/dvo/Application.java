package com.project.reated.job.dvo;


import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "applications")
public class Application {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int aplid;

	    @ManyToOne
	    @JoinColumn(name = "jobId", nullable = false)
	    private Job job;
	    

	    private String fullName;

	    private String email;

		public Application() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Application(int aplid, Job job, String fullName, String email) {
			super();
			this.aplid = aplid;
			this.job = job;
			this.fullName = fullName;
			this.email = email;
		}

		public int getAplid() {
			return aplid;
		}

		public void setAplid(int aplid) {
			this.aplid = aplid;
		}

		public Job getJob() {
			return job;
		}

		public void setJob(Job job) {
			this.job = job;
		}

		public String getFullName() {
			return fullName;
		}

		public void setFullName(String fullName) {
			this.fullName = fullName;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		@Override
		public int hashCode() {
			return Objects.hash(aplid, email, fullName, job);
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Application other = (Application) obj;
			return aplid == other.aplid && Objects.equals(email, other.email)
					&& Objects.equals(fullName, other.fullName) && Objects.equals(job, other.job);
		}

		@Override
		public String toString() {
			return "Application [aplid=" + aplid + ", job=" + job + ", fullName=" + fullName + ", email=" + email + "]";
		}
	
}
