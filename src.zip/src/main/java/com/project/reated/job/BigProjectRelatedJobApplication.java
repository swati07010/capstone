package com.project.reated.job;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BigProjectRelatedJobApplication {

	public static void main(String[] args) {
		SpringApplication.run(BigProjectRelatedJobApplication.class, args);
	}

}
