package com.project.reated.job.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.reated.job.dvo.Job;
import com.project.reated.job.service.JobService;

@RestController
@RequestMapping("/api/jobs")
//@CrossOrigin(origins = "http://localhost:5173")
@CrossOrigin(origins = "*")

public class JobController {
	
	@Autowired
    private JobService jobService;
	
	// Get all jobs
    @GetMapping
    public List<Job> getAllJobs() {
        return jobService.getAllJobs();
    }
    
   
    
    @GetMapping("/{id}")
    public ResponseEntity<Job> getJobById(@PathVariable("id") int jobid) {
        Job job = jobService.getJobById(jobid);
        if (job == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(job);
    }
    
    
    
    // Save a new job posting
    @PostMapping
    public ResponseEntity<Job> createJob(@RequestBody Job job) {
        Job savedJob = jobService.saveJob(job);
        return ResponseEntity.status(201).body(savedJob);
    }
    
    
    @GetMapping("/search")
    public List<Job> searchJobs(@RequestParam(required = false) Integer jobid,
                                @RequestParam(required = false) String title,
                                @RequestParam(required = false) String company,
                                @RequestParam(required = false) String location) {
        return jobService.searchJobs(jobid, title, company, location);
    }
    
    @PutMapping("/{id}")
    public Job updateJob(@PathVariable int id, @RequestBody Job updatedJob) {
        return jobService.updateJob(id, updatedJob);
    }

	
}
