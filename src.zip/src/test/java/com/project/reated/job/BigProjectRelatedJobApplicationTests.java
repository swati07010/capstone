package com.project.reated.job;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BigProjectRelatedJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
