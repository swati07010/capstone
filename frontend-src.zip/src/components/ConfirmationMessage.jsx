import React from 'react';
import { Link } from 'react-router-dom';

const ConfirmationMessage = () => {
  return (
    <div className="container-fluid d-flex justify-content-center align-items-center vh-100">
      <div className=" p-5 text-center" style={{ maxWidth: '800px' }}>
        <h2 className="mb-3 text-success">Application Submitted Successfully! 🎉</h2>
        <p className="mb-4">Thank you for applying. We'll get back to you soon.</p>
        <Link to="/" className="btn btn-primary w-50 mx-auto">Back to Home</Link>
      </div>
    </div>
  );
};

export default ConfirmationMessage;
